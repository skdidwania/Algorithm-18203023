# assignment1Data

This package contains all the relevant files to compress/decompress for assignment1.

