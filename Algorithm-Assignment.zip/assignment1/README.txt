# HuffmanAlgorithm

HuffmanAlgorithm is the main class.

## Usage
Run all classes from root.
Check timing.txt for each time a file is compressed or decompressed in order to obtain the time taken to compress/decompress in milliseconds.

To compress a file: java assignment1/HuffmanAlgorithm - < assignment1Data/"sourceFile" > assignment1Data/"destinationFile"

To decompress a file: java assignment1/HuffmanAlgorithm + < assignment1Data/"sourceFile" > assignment1Data/"destinationFile"

To check the amount of bits of a file run: java BinaryDump 40 < "desired_file"


